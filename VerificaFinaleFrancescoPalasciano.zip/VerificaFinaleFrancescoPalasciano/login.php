<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Cental - Car Rent Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,400;0,700;0,900;1,400;1,700;1,900&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    <?php include('header.php');

    if($_POST){

		function error(&$error_message,$message){
			    $error_message = $message;
		};

        $username = isset($_POST['username']) && $_POST['username'] != "" ? filter_var(trim($_POST['username']), FILTER_DEFAULT) : "";
        $pass = isset($_POST['pass']) && $_POST['pass'] != "" ? filter_var(trim($_POST['pass']), FILTER_DEFAULT) : "";

        if($username == "" || $pass == ""){
            error($error_message,"Inserisci campi validi");
        } else{
            $query = "SELECT * FROM utenti WHERE username = ?";
            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, 's', $username);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if(mysqli_num_rows($result) == 0) error($error_message,"Nome utente e/o password non sono corretti");

            else{
                while($row = mysqli_fetch_array($result)){
                    $hashPass = $row['pass'];
                    if(password_verify($pass,$hashPass)){
                        unset($error_message);
                        $_SESSION['id'] = $row['id'];
                        $_SESSION['username'] = $row['username'];
                        header("Location: imieidati.php");
                        exit();
                    } else {
                        error($error_message,"Nome utente e/o password non sono corretti");
                    }
                }
            }
        }
	}


    ?>

    <div class="col-xl-6 wow fadeInUp" data-wow-delay="0.1s" style="margin:50px auto">
        <div class="bg-secondary p-5 rounded">
            <h3 class="text-primary mb-4">Login</h3>
            <form action="login.php" method="post">
                <div class="row g-4">
                    <div class="col-lg-12 col-xl-6">
                        <div class="form-floating">
                            <input type="text" name="username" class="form-control" id="name" placeholder="Inserisci username">
                            <label for="name">Username</label>
                        </div>
                    </div>
                    <div class="col-lg-12 col-xl-6">
                        <div class="form-floating">
                            <input type="password" name="pass" class="form-control" id="phone" placeholder="inserisci password">
                            <label for="phone">Password</label>
                        </div>
                    </div>
                    <div class="col-lg-12 alert alert-danger" style="display: <?php echo isset($error_message) ? 'flex' : 'none'; ?>;">
                        <p class="text-primary mb-4">
                            <?php echo isset($error_message) ? $error_message : ''; ?>
                        </p>
					</div>
                    
                    <div class="col-12">
                        <button class="btn btn-light w-100 py-3">Entra</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- Contact End -->

    <?php include('footer.php') ?>