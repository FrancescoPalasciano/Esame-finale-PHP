<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>Cental - Car Rent Website Template</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,400;0,700;0,900;1,400;1,700;1,900&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet"> 

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

        <!-- Libraries Stylesheet -->
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


        <!-- Customized Bootstrap Stylesheet -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>

        <?php include('header.php');
        
        $sqlfeat = "SELECT * FROM home WHERE paragrafo = 'features'";
        $sqlserv = "SELECT * FROM home WHERE paragrafo = 'services'";
        ?>
        
        


        <!-- Features Start -->
        <div class="container-fluid feature py-5">
            <div class="container py-5">
                <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 800px;">
                    <h1 class="display-5 text-capitalize mb-3">Cental <span class="text-primary">Features</span></h1>
                    <p class="mb-0"> Tutto cio presente qui sotto è stato inserito dinamicamente dal DB
                    </p>
                </div>
                <div class="row g-4 align-items-center">
                    <div class="col-xl-4">
                        <div class="row gy-4 gx-0">
                            
                                <?php 
                                $result = mysqli_query($conn,$sqlfeat);
                                $i = 0;
                                while ($row = mysqli_fetch_array($result) ){
                                    $i++;
                                    echo "
                                    <div class='col-12 wow fadeInUp' data-wow-delay='0.1s'>
                                    <div class='feature-item'>
                                    <div class='feature-icon'>
                                        <span class='fa fa-trophy fa-2x'></span>
                                    </div>
                                        <div class='ms-4'>
                                            <h5 class='mb-3'>". $row['titolo']."</h5>
                                            <p class='mb-0'>". $row['descrizione']."</p>
                                        </div>
                                    </div>
                                    </div>";
                                    if ($i == 2){
                                        break;
                                    }
                                
                                }
                                
                                
                                ?>
                                
                            
                        </div>
                    </div>
                    <div class="col-lg-12 col-xl-4 wow fadeInUp" data-wow-delay="0.2s">
                        <img src="img/features-img.png" class="img-fluid w-100" style="object-fit: cover;" alt="Img">
                    </div>
                    <div class="col-xl-4">
                        <div class="row gy-4 gx-0">
                            <?php 
                                $result = mysqli_query($conn,$sqlfeat);
                                $i = 0;
                                while ($row = mysqli_fetch_array($result) ){
                                    $i++;
                                    if ($i > 2){
                                        echo "
                                        <div class='col-12 wow fadeInUp' data-wow-delay='0.1s'>
                                        <div class='feature-item'>
                                        <div class='feature-icon'>
                                            <span class='fa fa-trophy fa-2x'></span>
                                        </div>
                                            <div class='ms-4'>
                                                <h5 class='mb-3'>". $row['titolo']."</h5>
                                                <p class='mb-0'>". $row['descrizione']."</p>
                                            </div>
                                        </div>
                                        </div>";
                                    }
                                
                                }
                            ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Features End -->

        <!-- Services Start -->
        <div class="container-fluid service py-5">
            <div class="container py-5">
                <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 800px;">
                    <h1 class="display-5 text-capitalize mb-3">Cental <span class="text-primary">Services</span></h1>
                    <p class="mb-0">Tutto cio presente qui sotto è stato inserito dinamicamente dal DB
                    </p>
                </div>
                <div class="row g-4">
                    <?php 
                        $result = mysqli_query($conn,$sqlserv);
                        
                        while ($row = mysqli_fetch_array($result) ){
                           echo "
                            <div class='col-md-6 col-lg-4 wow fadeInUp' data-wow-delay='0.1s'>
                                <div class='service-item p-4'>
                                    <div class='service-icon mb-4'>
                                        <i class='fa fa-phone-alt fa-2x'></i>
                                    </div>
                                    <h5 class='mb-3'>".$row['titolo']."</h5>
                                    <p class='mb-0'>". $row['descrizione']."</p>
                                </div>
                            </div>";
                        
                        }
                    ?>
                    
                </div>
            </div>
        </div>
        <!-- Services End -->

        <?php include('footer.php')?>