<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Cental - Car Rent Website Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,400;0,700;0,900;1,400;1,700;1,900&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>

    <?php include('header.php');

    if ($_POST) {

        // mi salvo il messaggio di errore
        function error(&$error_message, $message){
            $error_message = $message;
        };

        // salvo i dati utenti
        $username = isset($_POST['username']) && $_POST['username'] != "" ? filter_var(trim($_POST['username']), FILTER_DEFAULT) : "";
        $pass = isset($_POST['pass']) && $_POST['pass'] != "" ? filter_var(trim($_POST['pass']), FILTER_DEFAULT) : "";

        // faccio diversi controlli tipo campi non inseriti correttamente o username gia registrato
        if ($username == "" || $pass == "") error($error_message, "Campi non inseriti correttamente");
        else {
            $query = "SELECT * FROM utenti WHERE username = ?";

            $stmt = mysqli_prepare($conn, $query);
            mysqli_stmt_bind_param($stmt, 's', $username);
            mysqli_stmt_execute($stmt);
            $result = mysqli_stmt_get_result($stmt);

            if (mysqli_num_rows($result) == 0) {

                // mi preparo la query
                $hashPass = password_hash($pass, PASSWORD_BCRYPT);
                $sql = "INSERT INTO utenti (username,pass) VALUES ('$username', '$hashPass')";

                // $stmt = mysqli_prepare($conn, $query);
                // mysqli_stmt_bind_param($stmt, 'ss', $username, $pass);
                // $result = mysqli_stmt_get_result($stmt);

                $result = mysqli_query($conn,$sql);
                
                if (!$result) exit("<script>alert('Errore durante la registrazione');window.location.href='login.php';</script>");

                // salvo l'ultimo id
                $lastid= mysqli_insert_id($conn);

                // salvo l'anagrafia

                if (strpos($_POST['nome'], '\'') !== false) {
                    $nome = strtoupper(str_replace("'", "&#39;", filter_var(htmlspecialchars($_POST['nome']))));
                } else $nome = filter_var(htmlspecialchars($_POST['nome']));

                if (strpos($_POST['nome'], '\'') !== false) {
                    $cognome = strtoupper(str_replace("'", "&#39;", filter_var(htmlspecialchars($_POST['cognome']))));
                } else $cognome = filter_var(htmlspecialchars($_POST['cognome']));

                
                $email = $_POST['email'];
                $data = date('Y-m-d', strtotime($_POST['data']));
                $sesso = $_POST['sesso'];

                // preparo ed eseguo la query

                $sql = "INSERT INTO anagrafia (id,nome,cognome,email,dataNascita,sesso) VALUES ($lastid, '$nome','$cognome','$email','$data','$sesso')";
                // $stmt = mysqli_prepare($conn, $query);
                // mysqli_stmt_bind_param($stmt, 'isssss', $lastid, $nome,$cognome,$email,$data,$sesso);
                // mysqli_stmt_execute($stmt);

                // non so perche non va

                $result = mysqli_query($conn,$sql);
                if (!$result) error($error_message, 'Errore durante la registrazione');
                else exit("<script>alert('Registrazione effettuata con successo!');window.location.href='login.php';</script>");


            } error($error_message, "Username gia registrato!");
        
        }

    }

    ?>




    <div class="col-xl-6 wow fadeInUp" data-wow-delay="0.1s" style="margin:50px auto">
        <div class="bg-secondary p-5 rounded">
            <h3 class="text-primary mb-4">Registrati</h3>
            <form action="registrati.php" method="post">
                <div class="row g-4">
                    <div class="col-lg-12 col-xl-6">
                        <div class="form-floating">
                            <input type="text" name="username" class="form-control" id="name" placeholder="Inserisci username">
                            <label for="name">Username</label>
                        </div>
                    </div>
                    <div class="col-lg-12 col-xl-6">
                        <div class="form-floating">
                            <input type="email" name="email" class="form-control" id="email" placeholder="inserisci Email">
                            <label for="email">Email</label>
                        </div>
                    </div>
                    <div class="col-lg-12 col-xl-6">
                        <div class="form-floating">
                            <input type="password" name="pass" class="form-control" id="phone" placeholder="inserisci password">
                            <label for="phone">Password</label>
                        </div>
                    </div>
                    <div class="col-lg-12 col-xl-6">
                        <div class="form-floating">
                            <input type="date" name="data" class="form-control" id="project" placeholder="Data di nascita">
                            <label for="project">Data di Nascita</label>
                        </div>
                    </div>
                    <div class="col-12">
                        <select name="sesso" id="subject" class="form-control" required>
                            <option value="" disabled selected>Scegli Genere</option>
                            <option value="M">Maschio</option>
                            <option value="F">Femmina</option>
                        </select>
                    </div>
                    <div class="col-lg-12 col-xl-6">
                        <div class="form-floating">
                            <input type="text" name="nome" class="form-control" id="name" placeholder="Inserisci Nome">
                            <label for="name">Nome</label>
                        </div>
                    </div>
                    <div class="col-lg-12 col-xl-6">
                        <div class="form-floating">
                            <input type="text" name="cognome" class="form-control" id="email" placeholder="inserisci Cognome">
                            <label for="email">Cognome</label>
                        </div>
                    </div>
                    <div id="check" class="flex-col-c p-b-15 alert alert-danger" style="display: <?php echo isset($error_message) ? 'flex' : 'none'; ?>;">
						<p class="txt2">
							<?php echo isset($error_message) ? $error_message : ''; ?>
						</p>
					</div>
                    <div class="col-12">
                        <button class="btn btn-light w-100 py-3">Registrati</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <!-- Contact End -->

    <?php include('footer.php') ?>