<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="utf-8">
        <title>Cental - Car Rent Website Template</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Lato:ital,wght@0,400;0,700;0,900;1,400;1,700;1,900&family=Montserrat:ital,wght@0,100..900;1,100..900&display=swap" rel="stylesheet"> 

        <!-- Icon Font Stylesheet -->
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.4/css/all.css"/>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

        <!-- Libraries Stylesheet -->
        <link href="lib/animate/animate.min.css" rel="stylesheet">
        <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">


        <!-- Customized Bootstrap Stylesheet -->
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <!-- Template Stylesheet -->
        <link href="css/style.css" rel="stylesheet">
    </head>

    <body>

       <?php include('header.php');
       
       $id = $_SESSION['id'];
       $username = $_SESSION['username'];

       $sql = "SELECT * FROM anagrafia WHERE id = $id";

       $result = mysqli_query($conn,$sql);

        while($row = mysqli_fetch_array($result)){
            $nome = $row['nome'];
            $cognome = $row['cognome'];
            $dataNascita = $row['dataNascita'];
            $email = $row['email'];
            $sesso = $row['sesso'];
        }
       
       
       
       
       
       
       
       
       ?>

        <!-- Team Start -->
        <div class="container-fluid team py-3">
            <div class="container ">
                <div class="text-center mx-auto pb-5 wow fadeInUp" data-wow-delay="0.1s" style="max-width: 800px;">
                    <h1 class="display-5 text-capitalize mb-10">I tuoi<span class="text-primary"> dati</span></h1>
                    <p class="mb-0">
                    </p>
                </div>
                <div class="row g-4">
                    <div class="col-md-6 col-lg-6 col-xl-3 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="team-item p-4 pt-0">
                            <div class="team-img">
                                <img src="img/team-1.jpg" class="img-fluid rounded w-100" alt="Image">
                            </div>
                            <div class="team-content pt-4">
                                <h4><?php echo $nome . " ". $cognome;    ?></h4>
                                <p><?php echo $email;    ?></p>
                                <div class="team-icon d-flex justify-content-center">
                                    <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i class="fab fa-instagram"></i></a>
                                    <a class="btn btn-square btn-light rounded-circle mx-1" href=""><i class="fab fa-linkedin-in"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                        <div class="col-md-6 col-lg-6 col-xl-3">
                            <div class="footer-item d-flex flex-column">
                                <h4 class="text-black mb-4">Le tue info:</h4>
                            <div class="mb-3">
                                <h6 class="text-muted mb-0">Username:</h6>
                                <p class="text-black mb-0"><?php echo $username;?></p>
                            </div>
                            <div class="mb-3">
                                <h6 class="text-muted mb-0">Data di nascita</h6>
                                <p class="text-black mb-0"><?php echo $dataNascita;?></p>
                            </div>
                            <div class="mb-3">
                                <h6 class="text-muted mb-0">Anni:</h6>
                                <p class="text-black mb-0"><?php $data = date('Y/m/d');
                                echo intval($data) - intval($dataNascita)?></p>
                            </div>
                            <div class="mb-3">
                                <h6 class="text-muted mb-0">Sesso:</h6>
                                <p class="text-black mb-0"><?php echo $sesso;?></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Team End -->

        <?php include('footer.php')?>