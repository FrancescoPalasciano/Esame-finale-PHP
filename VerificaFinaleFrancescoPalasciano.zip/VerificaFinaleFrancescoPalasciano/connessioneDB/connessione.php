<?php
include('config.php');

session_start();

$conn = mysqli_connect($host,$user,$password,$db);

if(!$conn) exit('Errore durante connessione con la base dati!');