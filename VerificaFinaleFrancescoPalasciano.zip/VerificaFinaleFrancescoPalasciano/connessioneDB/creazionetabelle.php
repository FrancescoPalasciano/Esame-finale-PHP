<?php

include('connessione.php');

$sql = 'CREATE TABLE header (
id int PRIMARY KEY auto_increment,
nome VARCHAR(50) not null,
link VARCHAR(50) not null,
tipo int not null,)';


$sql = 'CREATE TABLE utenti (
id int PRIMARY KEY auto_increment,
username VARCHAR(50) not null,
pass VARCHAR(256) not null)';

$sql = 'CREATE TABLE anagrafia (
id int PRIMARY KEY,
nome VARCHAR(50) not null,
cognome VARCHAR(50) not null,
dataNascita date,
email VARCHAR(50) not null,
FOREIGN KEY (id) REFERENCES utenti(id))';


$sql = 'CREATE TABLE home (
id int PRIMARY KEY auto_increment,
titolo VARCHAR(50) not null,
descrizione VARCHAR(500) not null,
paragrafo varchar(30) not null)';

$sql = 'CREATE TABLE footer (
id int PRIMARY KEY auto_increment,
nome VARCHAR(50) not null,
link VARCHAR(50) not null)';


// $sql = "INSERT INTO header (nome,link,tipo) VALUES ('I miei dati','imieidati.php',0),('Login','login.php',0),('Registrati','login.php',0),('Logout','logout.php',0)";

// $sql = "INSERT INTO home (titolo,descrizione,paragrafo) VALUES ('Phone Reservation','Descrizione della Phone Reservation','services'),('Special Rates','Descrizione della Special Rates','services'),('Special Rates','Descrizione della Special Rates','services')";

$sql = "INSERT INTO footer (nome,link) VALUES ('Su di noi','about.net'),('Le nostre macchine','macchine'),('Squadra','squadra.php'),('contattaci','contattaci')";


if(false=== mysqli_query($conn, $sql)){
    exit ("Errore: impossibile eseguire la query. ". mysqli_error($conn));
}

echo "Tabella creata con successo";

mysqli_close($conn);
?>