<?php
$db = 'centalrent';
$user = 'root';
$host ='localhost';
$password ='';