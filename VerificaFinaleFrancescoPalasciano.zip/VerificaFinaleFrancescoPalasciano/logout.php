<?php 
 include('../VerificaFinaleFrancescoPalasciano/connessioneDB/connessione.php');


 if($_GET){
   session_destroy();
   header("Location: index.php");
   exit();
 }




?>